# Community case

We collected a lot of case feedback from the community, and also discovered Luckysheet usage scenarios that we did not expect before.

It is our responsibility to actively listen to the voice of the community, and to continuously update and iterate with your support and feedback.


## Company Case

<table>
  <tbody>
    <tr>
      <td align="center" valign="middle">
        <a href="https://www.zpy360.com/" target="_blank">
          <img width="222px" src="https://cdn.jsdelivr.net/npm/luckyresources/assets/img/community_case/Zhiping_Cloud.png">
        </a>
        <p>雄安智评云数字科技有限公司</p>
      </td>
      <td align="center" valign="middle">
        <a href="https://code-the-future.com/" target="_blank">
          <img width="222px" src="https://cdn.jsdelivr.net/npm/luckyresources/assets/img/community_case/code_the_future.png">
        </a>
        <p>Code the Future</p>
      </td>
      <td align="center" valign="middle">
        <a href="http://www.jackyun.com/" target="_blank">
          <img width="222px" src="https://cdn.jsdelivr.net/npm/luckyresources/assets/img/community_case/jackyun.png">
        </a>
        <p>吉客云</p>
      </td>
      <td align="center" valign="middle">
        <a href="https://www.huawei.com/cn/" target="_blank">
          <img width="222px" src="https://cdn.jsdelivr.net/npm/luckyresources/assets/img/community_case/huawei.png">
        </a>
        <p>华为</p>
      </td>
    </tr>
    <tr>
      <td align="center" valign="middle">
      </td>
      <td align="center" valign="middle">
      </td>
      <td align="center" valign="middle">
      </td>
      <td align="center" valign="middle">
      </td>
    </tr>
  </tbody>
</table>