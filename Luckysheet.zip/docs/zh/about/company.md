# 社区案例

我们搜集到了很多来自社区的案例反馈，还发现了以前我们没有预想到的Luckysheet使用场景。

积极聆听社区的声音，在大家的支持和反馈中不断更新迭代，已是我们的责任。


## 公司案例

<table>
  <tbody>
    <tr>
      <td align="center" valign="middle">
        <a href="https://www.zpy360.com/" target="_blank">
          <img width="222px" src="https://cdn.jsdelivr.net/npm/luckyresources/assets/img/community_case/Zhiping_Cloud.png">
        </a>
        <p>雄安智评云数字科技有限公司</p>
      </td>
      <td align="center" valign="middle">
        <a href="https://code-the-future.com/" target="_blank">
          <img width="222px" src="https://cdn.jsdelivr.net/npm/luckyresources/assets/img/community_case/code_the_future.png">
        </a>
        <p>Code the Future</p>
      </td>
      <td align="center" valign="middle">
        <a href="http://www.jackyun.com/" target="_blank">
          <img width="222px" src="https://cdn.jsdelivr.net/npm/luckyresources/assets/img/community_case/jackyun.png">
        </a>
        <p>吉客云</p>
      </td>
      <td align="center" valign="middle">
        <a href="https://www.huawei.com/cn/" target="_blank">
          <img width="222px" src="https://cdn.jsdelivr.net/npm/luckyresources/assets/img/community_case/huawei.png">
        </a>
        <p>华为</p>
      </td>
    </tr>
    <tr>
      <td align="center" valign="middle">
      </td>
      <td align="center" valign="middle">
      </td>
      <td align="center" valign="middle">
      </td>
      <td align="center" valign="middle">
      </td>
    </tr>
  </tbody>
</table>