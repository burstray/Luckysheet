---
name: Feature request
about: Suggest an idea for this project
title: "[Feature request]I have an idea"
labels: ''
assignees: ''

---

<!--- Thank you for your attention and submit the issue, we hope that besides submitting the issue, you can also help us to understand your user case of Luckysheet, please help fill out the following solicitation form -->

<!-- Wanted: Who is using Luckysheet https://github.com/mengshukeji/Luckysheet/issues/230 -->

<!-- The following is the issues template -->

**Is your feature request related to a problem? Please describe.**
<!--- A clear and concise description of what the problem is. -->

**Describe the solution you'd like**
<!--- A clear and concise description of what you want to happen. -->

**Additional context**
<!--- Add any other context or screenshots about the feature request here. -->
