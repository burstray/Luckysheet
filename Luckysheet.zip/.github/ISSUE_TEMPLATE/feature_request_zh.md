---
name: 功能要求
about: 为这个项目提出想法
title: "[Feature request]我有个点子"
labels: ''
assignees: ''

---

<!--- 感谢您的关注并发现问题,我们希望除了提交问题,还能帮助我们对您使用Luckysheet做进一步的了解,请帮忙填写以下征集表 -->

<!-- 征求：谁在使用Luckysheet https://github.com/mengshukeji/Luckysheet/issues/230 -->

<!-- 以下是issues正文模板 -->

**您的功能请求与问题有关吗？**
<!--- 清楚简洁地说明问题 -->


**描述您想要的解决方案**
<!--- 对您想要的功能效果简洁明了的描述 -->

**其他内容**
<!--- 其他说明 -->
